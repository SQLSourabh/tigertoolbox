--Run on Secondary Replica to join to the availability group
 ALTER AVAILABILITY GROUP DataBase_Failover_Demo JOIN
 GO  
 ALTER AVAILABILITY GROUP DataBase_Failover_Demo GRANT CREATE ANY DATABASE
 GO


